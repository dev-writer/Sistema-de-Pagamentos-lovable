import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Payments from "./pages/Payments";
import PaymentReports from "./pages/PaymentReports";
import AccountTransfers from "./pages/AccountTransfers";
import Accounts from "./pages/Accounts";
import Creditors from "./pages/Creditors";
import CreditorDashboard from "./pages/CreditorDashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/dashboard/:accountId" element={<Dashboard />} />
          <Route path="/creditor-dashboard/:creditorId" element={<CreditorDashboard />} />
          <Route path="/" element={<Payments />} />
          <Route path="/payment-reports" element={<PaymentReports />} />
          <Route path="/transfers" element={<AccountTransfers />} />
          <Route path="/accounts" element={<Accounts />} />
          <Route path="/creditors" element={<Creditors />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
